
require('dotenv').config();
const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..'))); // serve frontend files

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/marketing_site', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(()=> console.log('MongoDB connected')).catch(err=> console.error('MongoDB connection error:', err));

// User schema
const userSchema = new mongoose.Schema({
  username: {type: String, unique: true},
  email: {type: String, unique: true, sparse: true},
  passwordHash: String,
}, {timestamps: true});

const User = mongoose.model('User', userSchema);

// Routes
app.post('/api/auth/signup', async (req, res) => {
  const {username, email, password} = req.body;
  if (!username || !password) return res.status(400).json({message: 'Missing fields'});
  try {
    const bcrypt = require('bcrypt');
    const hash = await bcrypt.hash(password, 10);
    const user = new User({username, email, passwordHash: hash});
    await user.save();
    return res.json({message: 'User created'});
  } catch (err) {
    console.error(err);
    if (err.code === 11000) return res.status(400).json({message: 'Username or email already taken'});
    return res.status(500).json({message: 'Server error'});
  }
});

app.post('/api/auth/login', async (req, res) => {
  const {username, password} = req.body;
  if (!username || !password) return res.status(400).json({message: 'Missing fields'});
  try {
    const bcrypt = require('bcrypt');
    const user = await User.findOne({username});
    if (!user) return res.status(400).json({message: 'Invalid credentials'});
    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(400).json({message: 'Invalid credentials'});
    const jwt = require('jsonwebtoken');
    const token = jwt.sign({id: user._id, username: user.username}, process.env.JWT_SECRET || 'secret', {expiresIn: '7d'});
    return res.json({message: 'Logged in', token});
  } catch (err) {
    console.error(err);
    return res.status(500).json({message: 'Server error'});
  }
});

// A sample protected route
const authMiddleware = (req, res, next) => {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({message: 'No token'});
  const token = auth.split(' ')[1];
  try {
    const jwt = require('jsonwebtoken');
    const data = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = data;
    next();
  } catch (err) {
    return res.status(401).json({message: 'Invalid token'});
  }
};


const nodemailer = require('nodemailer');
// Nodemailer transporter using Gmail - uses environment variables
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS
  }
});

// POST /send-email route to forward contact form to owner's Gmail
app.post('/send-email', async (req, res) => {
  const { name, email, phone, message } = req.body || {};
  if (!name || !email || !message) return res.status(400).json({ success:false, error: 'Missing fields' });
  const mailOptions = {
    from: process.env.GMAIL_USER,
    to: process.env.GMAIL_USER, // send to owner's Gmail
    subject: `Website Contact: ${name}`,
    text: `You have a new message from your website contact form.

Name: ${name}
Email: ${email}
Phone: ${phone || 'N/A'}

Message:
${message}`
  };
  try {
    await transporter.sendMail(mailOptions);
    return res.json({ success: true });
  } catch (err) {
    console.error('Error sending email:', err);
    return res.status(500).json({ success:false, error: err.message });
  }
});

app.get('/api/profile', authMiddleware, async (req, res) => {
  const user = await User.findById(req.user.id).select('-passwordHash');
  res.json({user});
});

// Start server
app.listen(PORT, () => console.log('Server started on port', PORT));
